# java-calculator
Very simple java calculator with basic functionalities for simple Maths calculations


![Calculator 5_18_2023 10_14_13 AM](https://github.com/TheCodeDaniel/java-calculator/assets/130862856/b2cf73a2-1fcd-45e4-ba42-697f8dcb702c)
