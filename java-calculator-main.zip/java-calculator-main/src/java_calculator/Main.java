package java_calculator;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// creating object of main class
		MainClass main = new MainClass();
		
		
		// calling the calculator function from the class
		main.calculator();

	}

}
